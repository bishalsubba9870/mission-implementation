"""
GPS-capable UAV Expert System Knowledge Base.
"""

from __future__ import annotations

from typing import Any

from mission_formalism_evaluation.expert_system.rule_engine import (
    FactMap,
    Rule,
)


GPS_FAILURE_PRIORITY = 1
GPS_RECOVERY_PRIORITY = 2
GPS_LOST_PRIORITY = 3
SAFE_TERMINATION_PRIORITY = 4

NORMAL_PRIORITY = 10
COMPLETION_PRIORITY = 20


# ================================================================
# Nominal mission conditions
# ================================================================

def task_is(
    task_type: str,
):
    def check(
        facts: FactMap,
    ) -> bool:

        return (
            not facts.get(
                "mission_complete",
                False,
            )
            and not facts.get(
                "all_tasks_processed",
                False,
            )
            and not facts.get(
                "mission_interrupted",
                False,
            )
            and str(
                facts.get(
                    "current_task_type",
                    "",
                )
            ).lower()
            == task_type
        )

    return check


def task_is_other(
    facts: FactMap,
) -> bool:

    task_type = str(
        facts.get(
            "current_task_type",
            "",
        )
    ).lower()

    return (
        not facts.get(
            "mission_complete",
            False,
        )
        and not facts.get(
            "all_tasks_processed",
            False,
        )
        and not facts.get(
            "mission_interrupted",
            False,
        )
        and bool(
            task_type
        )
        and task_type
        not in {
            "takeoff",
            "navigate",
            "land",
        }
    )


def mission_finished(
    facts: FactMap,
) -> bool:

    return (
        facts.get(
            "all_tasks_processed",
            False,
        )
        and not facts.get(
            "mission_complete",
            False,
        )
        and not facts.get(
            "safe_terminated",
            False,
        )
    )


# ================================================================
# GPS conditions
# ================================================================

def gps_lost(
    facts: FactMap,
) -> bool:

    return (
        facts.get(
            "mission_interrupted",
            False,
        )
        and facts.get(
            "gps_was_lost",
            False,
        )
        and not facts.get(
            "gps_available",
            True,
        )
        and not facts.get(
            "gps_recovery_failed",
            False,
        )
        and not facts.get(
            "safe_terminated",
            False,
        )
    )


def gps_restored(
    facts: FactMap,
) -> bool:

    return (
        facts.get(
            "mission_interrupted",
            False,
        )
        and facts.get(
            "gps_was_lost",
            False,
        )
        and facts.get(
            "gps_available",
            False,
        )
        and not facts.get(
            "gps_recovery_failed",
            False,
        )
        and not facts.get(
            "safe_terminated",
            False,
        )
    )


def gps_failed(
    facts: FactMap,
) -> bool:

    return (
        facts.get(
            "mission_interrupted",
            False,
        )
        and facts.get(
            "gps_was_lost",
            False,
        )
        and facts.get(
            "gps_recovery_failed",
            False,
        )
        and not facts.get(
            "safe_terminated",
            False,
        )
    )


def safe_termination_ready(
    facts: FactMap,
) -> bool:

    return (
        facts.get(
            "safe_termination_ready",
            False,
        )
        and not facts.get(
            "safe_terminated",
            False,
        )
    )


# ================================================================
# Nominal mission actions
# ================================================================

def select_takeoff(
    _facts: FactMap,
) -> dict[str, Any]:

    return {
        "decision": "TAKEOFF",
    }


def select_navigate(
    _facts: FactMap,
) -> dict[str, Any]:

    return {
        "decision": "NAVIGATE",
    }


def select_mission_action(
    _facts: FactMap,
) -> dict[str, Any]:

    return {
        "decision": "MISSION_ACTION",
    }


def select_land(
    _facts: FactMap,
) -> dict[str, Any]:

    return {
        "decision": "LAND",
    }


def complete_mission(
    _facts: FactMap,
) -> dict[str, Any]:

    return {
        "decision": "MISSION_COMPLETE",
        "mission_complete": True,
    }


# ================================================================
# GPS recovery actions
# ================================================================

def wait_for_gps(
    _facts: FactMap,
) -> dict[str, Any]:

    return {
        "decision": "WAIT_FOR_GPS",
    }


def resume_after_gps(
    _facts: FactMap,
) -> dict[str, Any]:

    return {
        "decision": "RESUME_MISSION",
        "mission_interrupted": False,
        "gps_was_lost": False,
        "gps_recovery_failed": False,
    }


def land_after_gps_failure(
    _facts: FactMap,
) -> dict[str, Any]:

    return {
        "decision": "EMERGENCY_LAND",
        "mission_interrupted": False,
        "termination_reason":
            "GPS_RECOVERY_FAILED",
    }


def safe_terminate(
    _facts: FactMap,
) -> dict[str, Any]:

    return {
        "decision": "SAFE_TERMINATE",
        "safe_terminated": True,
        "mission_complete": True,
        "safe_termination_ready": False,
    }


# ================================================================
# Event-to-fact translation
# ================================================================

RUNTIME_EVENT_UPDATES: dict[
    str,
    dict[str, Any],
] = {

    "GPS_LOST": {
        "gps_available": False,
        "gps_was_lost": True,
        "gps_recovery_failed": False,
        "mission_interrupted": True,
    },

    "GPS_AVAILABLE": {
        "gps_available": True,
    },

    "GPS_RECOVERY_FAILED": {
        "gps_available": False,
        "gps_recovery_failed": True,
    },
}


# ================================================================
# Knowledge Base construction
# ================================================================

def build_gps_knowledge_base(
) -> list[Rule]:
    """Build the GPS-capable UAV production-rule Knowledge Base."""

    return [
        Rule(
            name="r_gps_recovery_failed",
            priority=GPS_FAILURE_PRIORITY,
            condition=gps_failed,
            action=land_after_gps_failure,
        ),

        Rule(
            name="r_gps_restored",
            priority=GPS_RECOVERY_PRIORITY,
            condition=gps_restored,
            action=resume_after_gps,
        ),

        Rule(
            name="r_gps_lost",
            priority=GPS_LOST_PRIORITY,
            condition=gps_lost,
            action=wait_for_gps,
        ),

        Rule(
            name="r_safe_terminate",
            priority=SAFE_TERMINATION_PRIORITY,
            condition=safe_termination_ready,
            action=safe_terminate,
        ),

        Rule(
            name="r_takeoff",
            priority=NORMAL_PRIORITY,
            condition=task_is(
                "takeoff"
            ),
            action=select_takeoff,
        ),

        Rule(
            name="r_navigate",
            priority=NORMAL_PRIORITY,
            condition=task_is(
                "navigate"
            ),
            action=select_navigate,
        ),

        Rule(
            name="r_land",
            priority=NORMAL_PRIORITY,
            condition=task_is(
                "land"
            ),
            action=select_land,
        ),

        Rule(
            name="r_mission_action",
            priority=NORMAL_PRIORITY,
            condition=task_is_other,
            action=select_mission_action,
        ),

        Rule(
            name="r_mission_complete",
            priority=COMPLETION_PRIORITY,
            condition=mission_finished,
            action=complete_mission,
        ),
    ]
